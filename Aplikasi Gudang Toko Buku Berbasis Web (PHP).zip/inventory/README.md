# Inventory Toko Buku
Website tugas akhir dari mata kuliah Pemrograman Web

Tata cara instalasi :
  - Buat database dengan nama "ta_pemrograman_web_2"
  - Import database pada folder "Database" 
  - Login dengan username : admin | password : admin
  
  ![alt text](https://github.com/tegarpratama/inventory-toko-buku/blob/master/capture-1.png?raw=true) 
