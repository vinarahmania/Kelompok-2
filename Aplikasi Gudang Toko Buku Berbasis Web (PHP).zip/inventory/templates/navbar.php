<nav class="navbar navbar-dark fixed-top bg-dark flex-md-nowrap p-0 shadow">
   <a class="navbar-brand col-sm-3 col-md-2 mr-0" href="#">
      Gramedia Inventory App | Repost by <a href='https://stokcoding.com/' title='StokCoding.com' target='_blank'>StokCoding.com</a>
      
   </a>
   <ul class="navbar-nav px-3">
      <li class="nav-item text-nowrap">
         <a class="nav-link" href="logout.php">Sign out</a>
      </li>
   </ul>
</nav>