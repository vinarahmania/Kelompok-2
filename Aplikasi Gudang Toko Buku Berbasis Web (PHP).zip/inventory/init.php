<?php
   session_start();

   include_once('class/Auth.php'); 
   include_once('class/Crud.php');
   include_once('library/Flasher.php');
   
?>